function function1() {
  document.getElementById("audio1").play();
}
function function2() {
  document.getElementById("audio2").play();
}
function function3() {
  document.getElementById("audio3").play();
}
function function4() {
  document.getElementById("audio4").play();
}
function function5() {
  document.getElementById("audio5").play();
}